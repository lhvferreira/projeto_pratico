package com.example.projetopraticoemsistemas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText usuario, senha;
    Button btLogin, btCadastro;
    DBHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);
        usuario =findViewById(R.id.editTextUser);
        senha=findViewById(R.id.editTextSenha);
        btLogin=(Button) findViewById(R.id.buttonLogin);
        btCadastro=(Button) findViewById(R.id.btCadastro);


        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)



            {
                String username=usuario.getText().toString();
                String password=senha.getText().toString();

                if(username.equals("")){
                    Toast.makeText(MainActivity.this, "Usuario não inserido, tente novamente.", Toast.LENGTH_SHORT).show();
                }
                else if(password.equals("")){
                    Toast.makeText(MainActivity.this, "Senha não inserida, tente novamente.", Toast.LENGTH_SHORT).show();
                } else {
                String res = db.ValidarLogin(username, password);
                    if(res.equals("OK")){
                        Toast.makeText(MainActivity.this, "LOGIN OK.", Toast.LENGTH_SHORT).show();
                        Intent itLogin = new Intent(MainActivity.this, TelaInicio.class);
                        startActivity(itLogin);
                    } else {
                        Toast.makeText(MainActivity.this, "Login não encontrado.", Toast.LENGTH_SHORT).show();
                    }
                }



            };
        });
        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent itLogin = new Intent(MainActivity.this, ActivityCadastro.class);
                startActivity(itLogin);
            };
        });


    }
}
