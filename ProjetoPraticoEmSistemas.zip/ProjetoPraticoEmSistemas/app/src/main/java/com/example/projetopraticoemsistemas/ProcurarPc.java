package com.example.projetopraticoemsistemas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ProcurarPc extends AppCompatActivity {
    Button btGamer,  btHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_procurarpc);
        btGamer=findViewById(R.id.btCategoriaGamer);
        btHome=findViewById(R.id.btCategoriaHome);


        btGamer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itBtGamer = new Intent(ProcurarPc.this, TelaMontagemGamer.class);
                startActivity(itBtGamer);

            }
        });

        btHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itBtHome = new Intent(ProcurarPc.this, TelaMontagemHome.class);
                startActivity(itBtHome);
            }
        });


    }
}
