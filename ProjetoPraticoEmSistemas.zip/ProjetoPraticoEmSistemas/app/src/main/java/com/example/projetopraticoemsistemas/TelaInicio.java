package com.example.projetopraticoemsistemas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class TelaInicio extends AppCompatActivity {

    Button btMontar, btPecas;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btMontar=findViewById(R.id.btProcurarPc);
        btPecas=findViewById(R.id.btProcurarPecas);

        btMontar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent itMontar = new Intent(TelaInicio.this, ProcurarPc.class);
                startActivity(itMontar);

            };
        });

    }




}





