package com.example.projetopraticoemsistemas;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityCadastro extends AppCompatActivity {

    EditText etUsuario, etSenha, etEmail, etConfirmaSenha, etTelefone;
    Button btCadastrar;
    DBHelper db;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        db = new DBHelper(this);

        etUsuario=findViewById(R.id.editTextUsuario);
        etEmail=findViewById(R.id.editTextEmail);
        etSenha=findViewById(R.id.editTextSenha);
        etConfirmaSenha=findViewById(R.id.editTextConfirmarSenha);
        etTelefone=findViewById(R.id.editTextTelefone);
        btCadastrar=(Button) findViewById(R.id.btCadastrarCliente);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsuario.getText().toString();
                String password = etSenha.getText().toString();
                String password2 = etConfirmaSenha.getText().toString();

                if(username.equals("")){
                    Toast.makeText(ActivityCadastro.this, "Usuario não inserido, tente novamente.", Toast.LENGTH_SHORT).show();
                }
                else if(password.equals("") || password2.equals("")){
                    Toast.makeText(ActivityCadastro.this, "Senha não inserida, tente novamente.", Toast.LENGTH_SHORT).show();
                }
                else if(!password.equals(password2)){
                    Toast.makeText(ActivityCadastro.this, "Confirmação de senha não bate, tente novamente.", Toast.LENGTH_SHORT).show();
            } else {
                long res = db.CriarUtilizador(username, password);
                    if (res>0) {
                        Toast.makeText(ActivityCadastro.this, "Registro OK.", Toast.LENGTH_SHORT).show();
                } else {
                        Toast.makeText(ActivityCadastro.this, "Registro Inválido.", Toast.LENGTH_SHORT).show();
                    }
            }
        }


        });
}}
